# AstroCom

This repository is part of the **Hawk Eye The Rapper Digital Ecosystem**.

## 🚀 Setup Instructions

1. Clone the repository:
   ```sh
   git clone https://github.com/YOUR_USERNAME/astrocom.git
   cd astrocom
   ```

2. Follow platform-specific instructions below.

## 🌐 Deployment
- Hosted on **Cloudflare Pages & Workers**
- Optimized for **performance & scalability**
