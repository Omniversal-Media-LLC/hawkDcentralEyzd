<?php

namespace App\Http\Controllers;

class StaticPageController extends Controller {
    public function about() {
        return view('about');
    }
    public function contact() {
        return view('contact');
    }
}