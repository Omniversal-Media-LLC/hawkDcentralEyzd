<?php

use Illuminate\Support\Facades\Route;

Route::get('/', [App\Http\Controllers\HomeController::class, 'index']);
Route::get('/shop', [App\Http\Controllers\ShopController::class, 'index']);
Route::get('/shop/{category}', [App\Http\Controllers\CategoryController::class, 'show']);
Route::get('/product/{slug}', [App\Http\Controllers\ProductController::class, 'show']);
Route::get('/about', [App\Http\Controllers\StaticPageController::class, 'about']);
Route::get('/contact', [App\Http\Controllers\StaticPageController::class, 'contact']);
Route::get('/blog', [App\Http\Controllers\BlogController::class, 'index']);
Route::get('/blog/{slug}', [App\Http\Controllers\BlogController::class, 'show']);
Route::get('/cart', [App\Http\Controllers\CartController::class, 'index']);
Route::get('/checkout', [App\Http\Controllers\CheckoutController::class, 'index']);
Route::middleware('auth')->group(function () {
    Route::get('/account', [App\Http\Controllers\UserController::class, 'dashboard']);
});
