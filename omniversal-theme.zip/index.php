
<?php
// Template for displaying main content
get_header();
?>

<main class="main-content">
  <div class="container">
    <div class="row">
      <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>
            <div class="entry-content">
              <?php the_content(); ?>
            </div>
          </article>
        <?php endwhile; ?>
      <?php else : ?>
        <p><?php esc_html_e('Sorry, no posts found.'); ?></p>
      <?php endif; ?>
    </div>
  </div>
</main>

<?php get_footer(); ?>
