
<?php
// Enqueue theme styles and scripts
function omniversal_theme_enqueue_styles() {
    wp_enqueue_style('style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'omniversal_theme_enqueue_styles');

// Register a primary menu
function omniversal_theme_setup() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'omniversal-theme')
    ));
}
add_action('after_setup_theme', 'omniversal_theme_setup');
