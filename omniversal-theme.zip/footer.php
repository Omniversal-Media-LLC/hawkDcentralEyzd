
<footer>
    <div class="footer-content">
        <p>&copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
        <p>Contact: <a href="mailto:HawkEye@omniversalmedia.net">HawkEye@omniversalmedia.net</a></p>
    </div>
    <?php wp_footer(); ?>
</footer>
</body>
</html>
